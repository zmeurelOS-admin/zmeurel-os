import { DashboardHome } from '@/components/dashboard/DashboardHome';

export default function DashboardPage() {
  return <DashboardHome />;
}