// src/app/(dashboard)/clienti/page.tsx
import { createClient } from '@/lib/supabase/server';
import { getClienti, type Client } from '@/lib/supabase/queries/clienti';
import { ClientPageClient } from './ClientPageClient';

export const metadata = {
  title: 'Clienți | Zmeurel OS',
  description: 'Gestionează baza de clienți',
};

export default async function ClientPage() {
  const supabase = await createClient();

  // Get authenticated user
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return (
      <div className="container mx-auto p-6">
        <p className="text-red-500">
          Trebuie să fii autentificat pentru a accesa această pagină.
        </p>
      </div>
    );
  }

  // Fetch clienți - RLS handles tenant filtering
  let clienti: Client[] = [];
  try {
    clienti = await getClienti();
    console.log('[ClientPage] Fetched clienti:', clienti.length);
  } catch (error) {
    console.error('[ClientPage] Error fetching clienti:', error);
  }

  // Pass data to Client Component
  return <ClientPageClient initialClienti={clienti} />;
}
