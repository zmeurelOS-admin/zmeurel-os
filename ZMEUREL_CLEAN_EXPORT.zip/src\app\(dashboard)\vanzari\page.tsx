// src/app/(dashboard)/vanzari/page.tsx
import { cookies } from 'next/headers';
import { createServerClient } from '@supabase/ssr';
import { VanzariPageClient } from './VanzariPageClient';

export default async function VanzariPage() {
  const cookieStore = await cookies();
  
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
      },
    }
  );

  // Get current user
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return <div>Autentificare necesară</div>;
  }

  // Fetch vânzări inițial (pentru SSR) - RLS handles tenant filtering
  const { data: vanzari = [] } = await supabase
    .from('vanzari')
    .select('*')
    .order('data', { ascending: false });

  // Fetch clienti pentru mapping (nume clienti) - RLS handles tenant filtering
  const { data: clienti = [] } = await supabase
    .from('clienti')
    .select('id, nume_client')
    .order('created_at', { ascending: false });

  // Map to Client interface expected by VanzariPageClient
  const mappedClienti = (clienti || []).map(c => ({
    id: c.id,
    nume: c.nume_client
  }));

  return (
    <VanzariPageClient
      initialVanzari={vanzari || []}
      clienti={mappedClienti}
    />
  );
}
