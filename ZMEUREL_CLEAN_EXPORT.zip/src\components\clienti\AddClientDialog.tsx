// src/components/clienti/AddClientDialog.tsx
'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';

// ========================================
// ZOD VALIDATION SCHEMA
// ========================================

const clientSchema = z.object({
  nume_client: z.string().min(2, 'Numele trebuie să aibă minim 2 caractere'),
  telefon: z.string().optional(),
  email: z.string().email('Email invalid').or(z.literal('')).optional(),
  adresa: z.string().optional(),
  pret_negociat_lei_kg: z.string().optional(),
  observatii: z.string().optional(),
});

type ClientFormData = z.infer<typeof clientSchema>;

// ========================================
// COMPONENT
// ========================================

interface AddClientDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: ClientFormData) => Promise<void>;
}

export function AddClientDialog({
  open,
  onOpenChange,
  onSubmit,
}: AddClientDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<ClientFormData>({
    resolver: zodResolver(clientSchema),
    defaultValues: {
      nume_client: '',
      telefon: '',
      email: '',
      adresa: '',
      pret_negociat_lei_kg: '',
      observatii: '',
    },
  });

  const handleSubmit = async (data: ClientFormData) => {
    setIsSubmitting(true);
    try {
      await onSubmit(data);
      form.reset();
      onOpenChange(false);
    } catch (error) {
      console.error('Error creating client:', JSON.stringify(error, null, 2));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="sm:max-w-[500px] max-h-[75vh] overflow-y-auto"
        style={{ backgroundColor: 'white' }}
      >
        <DialogHeader>
          <DialogTitle>Adaugă Client Nou</DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-3">
          {/* Nume Client */}
          <div className="space-y-1">
            <Label htmlFor="nume_client" className="text-sm">
              Nume Client <span className="text-red-500">*</span>
            </Label>
            <Input
              id="nume_client"
              {...form.register('nume_client')}
              placeholder="Ex: Restaurant La Zmeură"
              style={{ backgroundColor: 'white', color: 'black' }}
            />
            {form.formState.errors.nume_client && (
              <p className="text-xs text-red-500">
                {form.formState.errors.nume_client.message}
              </p>
            )}
          </div>

          {/* Telefon */}
          <div className="space-y-1">
            <Label htmlFor="telefon" className="text-sm">Telefon</Label>
            <Input
              id="telefon"
              {...form.register('telefon')}
              placeholder="Ex: 0740123456"
              type="tel"
              style={{ backgroundColor: 'white', color: 'black' }}
            />
          </div>

          {/* Email */}
          <div className="space-y-1">
            <Label htmlFor="email" className="text-sm">Email</Label>
            <Input
              id="email"
              {...form.register('email')}
              placeholder="Ex: contact@restaurant.ro"
              type="email"
              style={{ backgroundColor: 'white', color: 'black' }}
            />
            {form.formState.errors.email && (
              <p className="text-xs text-red-500">
                {form.formState.errors.email.message}
              </p>
            )}
          </div>

          {/* Adresă */}
          <div className="space-y-1">
            <Label htmlFor="adresa" className="text-sm">Adresă</Label>
            <Textarea
              id="adresa"
              {...form.register('adresa')}
              placeholder="Ex: Str. Principală nr. 10, Suceava"
              rows={2}
              style={{ backgroundColor: 'white', color: 'black' }}
            />
          </div>

          {/* Preț Negociat */}
          <div className="space-y-1">
            <Label htmlFor="pret_negociat_lei_kg" className="text-sm">
              Preț Negociat (lei/kg)
            </Label>
            <Input
              id="pret_negociat_lei_kg"
              {...form.register('pret_negociat_lei_kg')}
              type="number"
              step="0.01"
              min="0"
              placeholder="Ex: 12.50"
              style={{ backgroundColor: 'white', color: 'black' }}
            />
            <p className="text-xs text-gray-500">
              Lasă gol pentru preț standard
            </p>
          </div>

          {/* Observații */}
          <div className="space-y-1">
            <Label htmlFor="observatii" className="text-sm">Observații</Label>
            <Textarea
              id="observatii"
              {...form.register('observatii')}
              placeholder="Ex: Are 15 lădițe returnabile"
              rows={2}
              style={{ backgroundColor: 'white', color: 'black' }}
            />
          </div>

          <DialogFooter className="pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Anulează
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              style={{ backgroundColor: '#F16B6B', color: 'white' }}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Se salvează...
                </>
              ) : (
                'Salvează Client'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
